// Finds the article in a page, in ibid's isolated world. Readability does the finding. What
// follows does the rest: what a page says about itself, the furniture Readability leaves
// behind, and a verdict on whether this is an article at all. What comes out is rebuilt from
// an allowlist, because a page's words may be read but its markup is never trusted.
const ibidExtract = (page, href) => {
  const clean = (text) => (typeof text === 'string' ? text : '').replace(/\s+/g, ' ').trim();
  if (page.contentType && page.contentType !== 'text/html' && page.contentType !== 'application/xhtml+xml') return { isArticle: false, reason: 'not a page' };
  // A site asking whether you're a person. Only you can answer, on the page itself.
  const bodyLength = (page.body?.textContent ?? '').length;
  if (/^(just a moment|human verification|attention required|one more step|security check|verify(ing)? you are|are you (a )?(human|robot))/i.test((page.title ?? '').trim())
    || (bodyLength < 2500 && page.querySelector('#challenge-form,#challenge-stage,.cf-turnstile,.g-recaptcha,.h-captcha,[id*="px-captcha"],iframe[src*="captcha" i]'))) {
    return { isArticle: false, reason: 'a human check' };
  }
  const here = new URL(href);
  const host = here.hostname.replace(/^www\./, '');

  const MONTHS = 'jan(uary)?|feb(ruary)?|mar(ch)?|apr(il)?|may|june?|july?|aug(ust)?|sep(t(ember)?)?|oct(ober)?|nov(ember)?|dec(ember)?';
  // A line that is only a date: "Oct 31, 2026 7:00 AM", "Friday, 30 October 2026", "July 2023".
  const DATE_LINE = new RegExp(`^[★•·\\s]*((published|posted|updated|last updated)( on)?:?\\s+)?((mon|tues?|wed(nes)?|thu(rs?)?|fri|sat(ur)?|sun)(day)?,?\\s+)?(\\d{1,2}(st|nd|rd|th)?\\s+(${MONTHS})\\.?(,?\\s+\\d{4})?|(${MONTHS})\\.?\\s+\\d{1,2}(st|nd|rd|th)?(,?\\s+\\d{4})?|(${MONTHS})\\.?\\s+\\d{4}|\\d{4}-\\d{2}-\\d{2})(\\s*(at\\s+)?\\d{1,2}(:\\d{2})?\\s*(am|pm)?(\\s+[a-z]{2,5})?)?\\s*(-\\s*link blog)?$`, 'i');

  // ---- What the page says about itself ---------------------------------------

  const metaContent = (...names) => {
    for (const name of names) {
      const tag = page.querySelector(`meta[property="${name}"],meta[name="${name}"]`);
      if (clean(tag?.content)) return clean(tag.content);
    }
    return '';
  };

  const linkedData = () => {
    const found = [];
    const walk = (node) => {
      if (Array.isArray(node)) { node.forEach(walk); return; }
      if (!node || typeof node !== 'object') return;
      if (node['@graph']) walk(node['@graph']);
      const types = [].concat(node['@type'] ?? []).map(String);
      if (types.some((t) => /(Article|BlogPosting|Report|Posting)$/.test(t))) found.push(node);
    };
    for (const script of page.querySelectorAll('script[type="application/ld+json"]')) {
      try { walk(JSON.parse(script.textContent)); } catch {}
    }
    return found.sort((a, b) => clean(b.articleBody).length - clean(a.articleBody).length)[0] ?? null;
  };

  const people = (value) => {
    const names = [].concat(value ?? [])
      .map((person) => clean(typeof person === 'string' ? person : person?.name))
      .filter((name) => name && !/^https?:/.test(name));
    return [...new Set(names)].join(', ');
  };

  const tidyAuthor = (name) => {
    if (DATE_LINE.test(clean(name))) return '';
    const tidied = clean(name)
      .replace(/^(written |words |story |reporting )?by\b[:\s]*/i, '')
      .replace(/\s*\|.*$/, '')
      .replace(new RegExp(`\\s+(on\\s+)?(${MONTHS})\\b.*$`, 'i'), '')
      .replace(/\s*[,·•–—-]\s*(staff|contributor|correspondent|editor|reporter)\b.*$/i, '');
    const stem = host.split('.')[0].toLowerCase();
    if (tidied.length < 3 || tidied.length > 90 || tidied.toLowerCase() === stem) return '';
    if (/^https?:|contributors to|about the author|^(admin|staff|editors?|news desk)$|\(formerly|\d{4}/i.test(tidied)) return '';
    return tidied;
  };

  const data = linkedData();
  const pageAuthor = tidyAuthor(people(data?.author))
    || tidyAuthor(metaContent('author', 'article:author', 'parsely-author', 'sailthru.author', 'dc.creator', 'DC.creator', 'twitter:creator')
        .replace(/^@.*/, ''));

  const parseDate = (value) => {
    const text = clean(value);
    // A month and no day stays that way, as "2023-10". A day is never made up.
    if (/^[a-z]+\.? \d{4}$/i.test(text) || /^\d{4}-\d{2}$/.test(text)) {
      const time = Date.parse(/^\d/.test(text) ? `${text}-15T12:00:00Z` : `15 ${text} 12:00 UTC`);
      return Number.isNaN(time) ? '' : new Date(time).toISOString().slice(0, 7);
    }
    // A bare date is that day wherever you are, not midnight in London.
    const time = Date.parse(/^\d{4}-\d{2}-\d{2}$/.test(text) ? `${text}T12:00:00Z` : text);
    return Number.isNaN(time) ? '' : new Date(time).toISOString();
  };

  const publishedTime = () => {
    const tagged = page.querySelector('time[itemprop="datePublished"],time[pubdate]');
    if (tagged) return tagged;
    return [...page.querySelectorAll('article time[datetime],main time[datetime]')].find((time) => {
      const near = `${time.className} ${time.parentElement?.className ?? ''} ${clean(time.parentElement?.textContent).slice(0, 40)}`;
      return !/updat|modif|revis|edited/i.test(near);
    });
  };

  const urlDate = () => {
    const found = here.pathname.match(/\/(20\d{2})\/(\d{1,2}|[a-z]{3})\/(\d{1,2})(\/|$)/i);
    return found ? parseDate(`${found[2]} ${found[3]} ${found[1]} 12:00 UTC`) : '';
  };

  const pageDate = host.endsWith('wikipedia.org') ? '' : parseDate(data?.datePublished)
    // Only what's named as publication. A plain "date" tag is as often when a page last changed.
    || parseDate(metaContent('article:published_time', 'parsely-pub-date', 'pubdate', 'publishdate', 'dcterms.issued', 'dc.date.issued', 'sailthru.date'))
    || parseDate(publishedTime()?.getAttribute('datetime'))
    || urlDate();

  const pageSite = metaContent('og:site_name', 'application-name', 'al:ios:app_name') || clean(data?.publisher?.name);
  const pageKind = metaContent('og:type').toLowerCase();

  // ---- Clearing the way ------------------------------------------------------

  const clone = page.cloneNode(true);
  const body = clone.body;

  const FURNITURE = [
    'nav', 'footer', 'aside:not([class*="pull" i]):not([class*="quote" i])', 'form', 'dialog', 'noscript',
    'iframe:not([src*="youtu" i]):not([src*="vimeo" i])', 'button', 'select', 'input', 'textarea', 'svg:not(figure svg)',
    '[aria-hidden="true"]:not(img):not(figure)', '[hidden]', '[role="navigation"]', '[role="complementary"]', '[role="banner"]',
    '[role="contentinfo"]', '[role="dialog"]', '[role="alert"]',
    '[class*="newsletter" i]', '[id*="newsletter" i]', '[class*="subscribe" i]', '[id*="subscribe" i]', '[class*="signup" i]',
    '[class*="sign-up" i]', '[class*="related" i]', '[id*="related" i]', '[class*="recommend" i]',
    '[class*="promo" i]', '[class*="sponsor" i]', '[class*="advert" i]', '[id*="advert" i]', '[class^="ad-" i]', '[class*=" ad-" i]',
    '[id^="ad-" i]', '[id^="ad_" i]', '[class~="ad" i]', '[class~="ads" i]', '[data-ad]', '[class*="share" i]', '[class*="social" i]',
    '[class*="comment" i]:not(article)', '[id*="comments" i]', '[class*="most-read" i]', '[class*="mostread" i]', '[class*="popular" i]',
    '[class*="cookie" i]', '[id*="cookie" i]', '[class*="consent" i]', '[class*="breadcrumb" i]', '[class*="toolbar" i]',
    '[class*="author-bio" i]', '[class*="tags" i]', '[class*="read-more" i]', '[class*="readmore" i]', '[class*="more-from" i]',
    '[class*="up-next" i]', '[class*="upnext" i]', '[class*="trending" i]', '[data-testid*="promo" i]', '[data-component="links-block"]',
    '[data-component="related-internet-links"]', '[data-component="tags"]', '[data-component="topic-list"]',
  ];

  // Rules for the handful of sites worth knowing by name.
  const SITES = {
    'wikipedia.org': ['.mw-editsection', '.mw-references-wrap', '.citation', 'style', 'sup.reference', '.navbox', '.vertical-navbox', '.sistersitebox', '.metadata', '.hatnote', '#toc', '.toc', '.reflist', '.refbegin', '.ambox', '.noprint', '.mw-empty-elt'],
    'substack.com': ['.subscription-widget-wrap', '.post-footer', '.like-button-container', '.post-ufi'],
    'medium.com': ['[data-testid="headerSocialActions"]', '[data-testid="audioPlayButton"]', '.speechify-ignore'],
    'theverge.com': ['[class*="duet--article--comments"]', '[class*="follow" i]'],
    'nytimes.com': ['[data-testid="share-tools"]', '[id*="bottom-sheet" i]', '[data-testid*="brand-bar" i]'],
    'theguardian.com': ['[data-print-layout="hide"]', '[data-link-name="in body link"]:empty', 'gu-island[name*="Epic" i]', 'gu-island[name*="Most" i]'],
    'bbc.com': ['[data-component="ad-slot"]', '[data-component="byline-block"]', '[data-component="caption-block"]:empty'],
    'bbc.co.uk': ['[data-component="ad-slot"]', '[data-component="byline-block"]'],
  };

  const holdsProse = (el) => {
    let long = 0;
    for (const p of el.querySelectorAll('p')) {
      if (clean(p.textContent).split(' ').length >= 30 && ++long >= 3) return true;
    }
    return false;
  };

  const remove = (selectors) => {
    for (const selector of selectors) {
      let found;
      try { found = body.querySelectorAll(selector); } catch { continue; }
      for (const el of found) {
        // A class name that happens to match must never take the article with it.
        if (el.isConnected && !holdsProse(el)) el.remove();
      }
    }
  };

  // Writers of single-author sites that don't name themselves in their pages.
  const WRITERS = { 'paulgraham.com': 'Paul Graham', 'daringfireball.net': 'John Gruber', 'stratechery.com': 'Ben Thompson' };

  const siteRules = Object.keys(SITES).filter((site) => host === site || host.endsWith(`.${site}`)).flatMap((site) => SITES[site]);
  if (body) {
    remove(siteRules);
    if (host.endsWith('wikipedia.org')) {
      const end = body.querySelector('#See_also,#Notes,#References,#Footnotes,#Citations,#Sources,#Further_reading,#External_links,#Bibliography');
      const heading = end?.closest('.mw-heading') ?? end;
      // Reading on from the first closing heading, section by section.
      for (let at = heading; at && at !== body && at.parentElement; at = at.parentElement) {
        while (at.nextSibling) at.nextSibling.remove();
        if (at === heading) continue;
        if (/^(section|div)$/.test(at.localName) && at.id === 'mw-content-text') break;
      }
      heading?.remove();
    }
    remove(FURNITURE);
    for (const img of body.querySelectorAll('img[data-src],img[data-lazy-src],img[data-original]')) {
      const real = img.dataset.src ?? img.dataset.lazySrc ?? img.dataset.original;
      if (real) img.setAttribute('src', real);
    }
  }

  const read = (source) => {
    try {
      return new Readability(source, { charThreshold: 250, keepClasses: false, serializer: (el) => el }).parse();
    } catch { return null; }
  };

  // Clearing the way usually helps Readability and occasionally misleads it, so its answer is
  // checked against an untouched copy, and against the elements sites commonly put a story in.
  const BODIES = ['[itemprop="articleBody"]', '.available-content .body', '.post-content', '.entry-content', '.article-body', '.article__body', 'article', 'main'];
  const size = (found) => clean(found?.textContent).length;
  const attempts = [read(clone), read(page.cloneNode(true))];
  let parsed = attempts[0];
  if (size(attempts[1]) > size(parsed) * 4 || (size(parsed) < 3000 && size(attempts[1]) > size(parsed) * 1.5)) parsed = attempts[1];
  if (size(parsed) < 800) {
    const element = BODIES.map((selector) => page.querySelector(selector)).find((el) => size(el) > size(parsed) * 1.5 && size(el) > 400);
    if (element) {
      const shell = document.implementation.createHTMLDocument(page.title);
      shell.body.append(shell.importNode(element, true));
      parsed = { ...(parsed ?? {}), title: parsed?.title || page.title, content: shell.body, textContent: shell.body.textContent };
    }
  }
  if (!parsed?.content) return { isArticle: false, reason: 'empty' };

  // ---- Rebuilding from an allowlist ------------------------------------------

  const out = document.implementation.createHTMLDocument('');
  const root = out.createElement('div');

  const KEEP = new Set(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'blockquote', 'pre', 'code', 'em', 'strong', 'i', 'b', 'a',
    'figure', 'figcaption', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'br', 'hr', 'sub', 'sup', 'dl', 'dt', 'dd', 'cite', 'q', 'mark', 'del', 'ins', 'abbr', 'kbd', 'small']);
  const DROP = new Set(['script', 'style', 'template', 'object', 'embed', 'canvas', 'audio', 'link', 'meta', 'form', 'button', 'input', 'select', 'textarea', 'math']);
  const seen = new Set();

  const safeLink = (value) => {
    try {
      const url = new URL(value, href);
      return url.protocol === 'https:' || url.protocol === 'http:' ? url.href : '';
    } catch { return ''; }
  };

  const bestSource = (img) => {
    // Magazines put commas inside their picture addresses, so a comma alone doesn't end one.
    const lists = [img, ...(img.closest('picture')?.querySelectorAll('source') ?? [])]
      .map((el) => el.getAttribute('srcset') ?? '');
    const wide = lists
      .flatMap((list) => [...list.matchAll(/(\S*[^\s,])(?:\s+([\d.]+)[wx])?(?:\s*,\s*|\s*$)/g)])
      .map(([, url, size]) => ({ url, width: parseFloat(size) || 1 }))
      .filter((part) => part.width <= 1600)
      .sort((a, b) => b.width - a.width)[0];
    return safeLink(wide?.url || img.getAttribute('src') || '');
  };

  const image = (img) => {
    const source = bestSource(img);
    const width = parseInt(img.getAttribute('width') ?? '', 10);
    const height = parseInt(img.getAttribute('height') ?? '', 10);
    if (!source || !source.startsWith('https:') || seen.has(source)) return null;
    if ((width && width < 60) || (height && height < 60) || /\b(pixel|spacer|tracking|avatar|logo|sprite|blank)\b/i.test(source)) return null;
    seen.add(source);
    const copy = out.createElement('img');
    copy.setAttribute('src', source);
    if (img.getAttribute('alt')) copy.setAttribute('alt', img.getAttribute('alt').slice(0, 300));
    return copy;
  };

  const embed = (frame) => {
    const source = safeLink(frame.getAttribute('src') ?? '');
    if (!source) return null;
    const line = out.createElement('p');
    const link = out.createElement('a');
    link.setAttribute('href', source.replace('/embed/', '/watch?v=').replace('player.vimeo.com/video', 'vimeo.com'));
    link.textContent = 'Watch the video';
    line.append(link);
    return line;
  };

  const rebuild = (from, into) => {
    for (const node of from.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        into.append(out.createTextNode(node.data));
        continue;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) continue;
      const tag = node.localName;
      if (DROP.has(tag)) continue;
      if (tag === 'img' || tag === 'picture') {
        const img = tag === 'img' ? node : node.querySelector('img');
        const copy = img && image(img);
        if (copy) into.append(copy);
        continue;
      }
      if (tag === 'iframe' || tag === 'video') {
        const line = embed(tag === 'iframe' ? node : node.querySelector('source') ?? node);
        if (line) into.append(line);
        continue;
      }
      if (!KEEP.has(tag)) {
        rebuild(node, into);
        continue;
      }
      const copy = out.createElement(tag);
      if (tag === 'a') {
        const link = safeLink(node.getAttribute('href') ?? '');
        if (link) copy.setAttribute('href', link);
      }
      if ((tag === 'td' || tag === 'th') && node.hasAttribute('colspan')) copy.setAttribute('colspan', String(parseInt(node.getAttribute('colspan'), 10) || 1));
      rebuild(node, copy);
      into.append(copy);
    }
  };
  rebuild(parsed.content, root);

  // ---- Tidying ---------------------------------------------------------------

  const title = (() => {
    const heading = clean(page.querySelector('article h1,main h1,h1')?.textContent);
    const named = clean(parsed.title) || clean(data?.headline);
    // Sites add their own name to a title and rarely to the heading, and what a page's data
    // calls its headline isn't always one. A heading that the page's title agrees with wins.
    const isSiteName = (text) => text === pageSite || text.toLowerCase().replace(/[^a-z0-9]/g, '') === host.split('.')[0];
    const social = metaContent('og:title', 'twitter:title');
    if (heading && !isSiteName(heading) && (clean(page.title).includes(heading) || named.includes(heading))) return heading;
    if (heading && isSiteName(heading) && social && !isSiteName(social)) return social.replace(/\s+[|–—]\s+[^|–—]{2,40}$/, '');
    return named.replace(/\s+[|–—]\s+[^|–—]{2,40}$/, '') || heading || clean(page.title);
  })();

  const author = pageAuthor || tidyAuthor(parsed.byline) || (WRITERS[host] ?? '');
  const published = host.endsWith('wikipedia.org') ? '' : pageDate || parseDate(parsed.publishedTime);
  const site = host.endsWith('wikipedia.org') ? 'Wikipedia' : pageSite && !/^https?:/.test(pageSite) ? pageSite : host;

  const TAIL = /^(sign up|subscribe|follow (us|topics|authors)|follow this|share (this|on)|related:|read more|read next|more from|more on|see more|you might|you may also|recommended|most popular|most read|if you (like|enjoy)|join (us|our)|get (our|the) |download (our|the) |listen to |this (story|article) (was|is|has)|copyright|©|all rights reserved|was this|comments?$|tags?:|filed under|posted in|topics?(:|$)|support (our|us)|contact (us|the)|additional reporting|have a (story|tip)|tips?\?|got a (story|tip)|send (us|your)|advertisement|sponsored|lead image:|credits?$|wired coupons|in brief$)/i;
  const TAIL_ANYWHERE = /\b(sign up|subscribe to|newsletter|email updates|homepage feed|follow (us|topics)|editorial (independence|stance|policy)|for information purposes only|joining (us|cjr)|as a subscriber|send tips to|read more$|affiliate commission|may earn|block(ing)? (internet )?ads|ad.?blockers?|\d+ min(ute)? read$)\b/i;
  const HEAD = /^(listen( to)?( this)?( article)?|share( this)?|save( this)?( article| story)?|gift( this)?( article)?|print|comment|advertisement|\d+\s*(min|minute)s?( read| listen)?|read in app|skip (to|this)|updated|published|in brief|credits?|sign up for|subscribe to|image credits?:?|posted:?|\d{1,2}:\d{2}\s*(am|pm))\b.{0,50}$/i;
  const ENDINGS = /^(see also|references|external links|further reading|notes|footnotes|bibliography|sources|citations|works cited|related( articles| stories| posts)?|more (stories|articles)|you might also like|read more|recommended( for you| reading)?|comments?|about the author|about the authors?|share this( article| story)?|tags|topics)$/i;

  const blocksOf = () => [...root.children];
  const textOf = (el) => clean(el.textContent);
  const linkShare = (el) => {
    const words = textOf(el).length;
    if (!words) return 0;
    return [...el.querySelectorAll('a')].reduce((sum, a) => sum + textOf(a).length, 0) / words;
  };

  // Everything may be wrapped in a single element once rebuilt.
  while (root.children.length === 1 && !['p', 'ul', 'ol', 'table', 'pre', 'blockquote'].includes(root.firstElementChild.localName)) {
    root.firstElementChild.replaceWith(...root.firstElementChild.childNodes);
  }

  // Plain old pages set paragraphs with line breaks and no paragraph elements at all.
  const INLINE = new Set(['a', 'em', 'strong', 'i', 'b', 'code', 'sub', 'sup', 'cite', 'q', 'mark', 'del', 'ins', 'abbr', 'kbd', 'small']);
  const gatherLoose = (container) => {
    const runs = [[]];
    for (const node of [...container.childNodes]) {
      const isLoose = node.nodeType === Node.TEXT_NODE || INLINE.has(node.localName) || node.localName === 'br';
      if (isLoose) { runs[runs.length - 1].push(node); continue; }
      runs.push([]);
    }
    for (const run of runs) {
      let line = [];
      const close = (before) => {
        const hasWords = line.some((node) => clean(node.textContent));
        if (hasWords) {
          const p = out.createElement('p');
          line[0].before(p);
          p.append(...line);
        } else line.forEach((node) => node.remove());
        line = [];
      };
      run.forEach((node, index) => {
        if (node.localName === 'br' && run[index + 1]?.localName === 'br') { close(); node.remove(); return; }
        if (node.localName === 'br' && !line.length) { node.remove(); return; }
        line.push(node);
      });
      close();
    }
  };
  if ([...root.childNodes].some((node) => node.nodeType === Node.TEXT_NODE && clean(node.data))) gatherLoose(root);

  // A footnote marker left on its own goes back on the end of its sentence.
  for (const p of root.querySelectorAll('p')) {
    const before = p.previousElementSibling;
    if (before?.localName === 'p' && /^\[\d+\]$/.test(clean(p.textContent))) {
      before.append(' ', ...p.childNodes);
      p.remove();
    }
  }

  const emptied = (el) => !textOf(el) && !el.querySelector('img,hr');
  for (const el of root.querySelectorAll('p,li,h1,h2,h3,h4,h5,h6,blockquote,figure,figcaption,ul,ol,a,strong,em,b,i')) {
    if (el.isConnected && emptied(el)) el.remove();
  }

  const mention = author.toLowerCase();
  const writers = author.toLowerCase().split(/,\s*|\s+and\s+/);
  let dated = published;

  // The closing sections of a reference page, and anything after the last real paragraph.
  for (const el of blocksOf()) {
    if (/^h[1-6]$/.test(el.localName) && ENDINGS.test(textOf(el))) {
      const after = [];
      for (let next = el; next; next = next.nextElementSibling) after.push(next);
      const lost = after.reduce((sum, block) => sum + textOf(block).length, 0);
      if (lost < clean(root.textContent).length * 0.4) { after.forEach((block) => block.remove()); break; }
    }
  }

  const isTitleEcho = (el) => {
    const words = textOf(el).toLowerCase();
    return words === title.toLowerCase() || writers.includes(words.replace(/^by\s+/, '')) || words.replace(/^by\s+/, '') === mention;
  };

  for (let checks = 0; checks < 8; checks++) {
    const first = root.firstElementChild;
    if (!first) break;
    const words = textOf(first);
    const isShort = words.length < 120 && !first.querySelector('img');
    if (isShort && DATE_LINE.test(words)) {
      // "Updated 3 May" says when it changed, which isn't when it came out.
      if (!/updated/i.test(words)) dated ||= parseDate(words.replace(/^[^a-z0-9]+/i, '').replace(/^(published|posted)( on)?:?\s+/i, '').replace(/\s*-\s*link blog$/i, ''));
      first.remove();
    } else if (isShort && (isTitleEcho(first) || HEAD.test(words) || (/^(ul|ol)$/.test(first.localName) && linkShare(first) > 0.6))) {
      // A "Credits" heading introduces a line about the writer, which belongs at the end if anywhere.
      const next = first.nextElementSibling;
      if (/^credits?$/i.test(words) && next && textOf(next).length < 400) next.remove();
      first.remove();
    } else break;
  }

  for (let checks = 0; checks < 12; checks++) {
    const outer = root.lastElementChild;
    if (!outer) break;
    // The last words can sit a few elements down, in a list or a block of its own.
    const inner = outer.matches('figure,table,pre') ? null : [...outer.querySelectorAll('p,li,h2,h3,h4,h5,h6')].pop();
    const last = inner ?? outer;
    const words = textOf(last);
    const isShort = words.length < 220 && !last.matches('figure') && !last.querySelector('figure');
    const isAside = isShort && (TAIL.test(words) || TAIL_ANYWHERE.test(words) || DATE_LINE.test(words)
      || isTitleEcho(last) || (linkShare(last) > 0.6 && words.length < 160));
    const isHeading = /^h[1-6]$/.test(last.localName);
    if (!(isAside || isHeading || last.localName === 'hr')) break;
    if (DATE_LINE.test(words) && !/updated/i.test(words)) dated ||= parseDate(words.replace(/^[^a-z0-9]+/i, '').replace(/^(published|posted)( on)?:?\s+/i, ''));
    for (let gone = last, up; gone && gone !== root; gone = up) {
      up = gone.parentElement;
      gone.remove();
      if (textOf(up) || up.querySelector('img')) break;
    }
  }

  // Some sites lay a sign-up box over a story and leave its full text in the page's own data.
  // Nothing is fetched for this: it's only what the site has already sent to this browser.
  const fullText = String(data?.articleBody ?? '').replace(/<[^>]+>/g, ' ');
  if (clean(fullText).length > 600 && clean(fullText).length > clean(root.textContent).length * 1.3) {
    const lines = fullText.split(/\n+/).map(clean).filter(Boolean);
    const sentences = lines.length > 2 ? lines : clean(fullText).split(/(?<=[.!?”"])\s+(?=[A-Z“"])/);
    const gather = lines.length > 2 ? 1 : 4;
    root.replaceChildren();
    for (let at = 0; at < sentences.length; at += gather) {
      const p = out.createElement('p');
      p.textContent = sentences.slice(at, at + gather).join(' ');
      root.append(p);
    }
  }

  // ---- Plain text, for search, the library and reading aloud ---------------------

  const blocks = [];
  const BLOCK = 'p,h1,h2,h3,h4,h5,h6,li,blockquote,pre,figcaption,td';
  for (const el of root.querySelectorAll(BLOCK)) {
    if (el.parentElement.closest('blockquote,li,td,pre') && el.localName !== 'li') continue;
    if (el.localName === 'li' && el.parentElement.closest('li')) continue;
    const text = textOf(el);
    if (!text) continue;
    const kind = /^h[1-6]$/.test(el.localName) ? 'h' : el.localName === 'blockquote' ? 'q' : el.localName === 'li' ? 'l' : el.localName === 'figcaption' ? 'c' : 'p';
    blocks.push({ k: kind, t: text });
  }
  const prose = blocks.filter((block) => block.k === 'p' || block.k === 'q');
  const words = blocks.reduce((sum, block) => sum + block.t.split(' ').length, 0);

  // ---- Is this an article at all? -----------------------------------------------

  // Places made of something other than articles, whatever their pages claim to be.
  const NOT_ARTICLES = ['youtube.com', 'x.com', 'twitter.com', 'instagram.com', 'facebook.com', 'tiktok.com', 'linkedin.com', 'amazon.com', 'google.com', 'bing.com', 'duckduckgo.com'];
  const PAYWALL = /(subscribe|sign in|log in|register) to (unlock|read|continue|keep reading)|to continue reading|already a subscriber|unlock this article/i;

  const verdict = () => {
    if (NOT_ARTICLES.some((site) => host === site || host.endsWith(`.${site}`))) return 'not an article site';
    if (host.endsWith('reddit.com') && !here.pathname.includes('/comments/')) return 'a listing';
    if (words < 90) return 'too short';
    if (words < 500 && PAYWALL.test(clean(page.body?.textContent).slice(0, 20000))) return 'a paywall';
    const path = here.pathname.replace(/\/+$/, '');
    const isTopLevel = !path || path === '/index.html';
    const rooms = blocksOf().filter((el) => !/^(figure|hr)$/.test(el.localName));
    const linky = rooms.filter((el) => linkShare(el) > 0.55).length / Math.max(rooms.length, 1);
    const longParagraphs = prose.filter((block) => block.t.split(' ').length >= 18).length;
    const listed = blocks.filter((block) => block.k === 'l' && block.t.split(' ').length >= 18).length;
    const claimed = !!data || pageKind === 'article' || !!parsed.publishedTime;
    const isSection = /^(news|home|latest|top stories|search|index|archive)$/i.test(title);
    if (linky > 0.4 && !(claimed && path && words >= 200 && !isSection)) return 'a list of links';
    if (longParagraphs === 0 && !(claimed && listed >= 5)) return 'no paragraphs';
    if (isTopLevel && !claimed) return 'a home page';
    if (isTopLevel && longParagraphs < 4) return 'a home page';
    if (!claimed && prose.length && words / Math.max(blocks.length, 1) < 12) return 'a listing';
    if (isSection) return 'a section page';
    if (pageKind === 'website' && !data && longParagraphs < 3) return 'a listing';
    return '';
  };

  const reason = verdict();
  return {
    isArticle: !reason, reason, title, byline: author, site, published: dated,
    excerpt: clean(parsed.excerpt).slice(0, 280), html: root.innerHTML, blocks, words,
  };
};
