// Isolated-world helper for sign-in forms. Offers to save a password when a
// form is submitted, and fills one only when ibid explicitly asks after
// the person has approved it. Never fills on its own.
(() => {
  if (window.__c || location.protocol !== 'https:') return;

  const post = (m) => { try { webkit.messageHandlers.marginalia.postMessage(m); } catch {} };
  const visible = (el) => el.checkVisibility() && el.getBoundingClientRect().width > 0;
  const fields = (selector) => [...document.querySelectorAll(selector)].filter(visible);

  const passwordFields = () => fields('input[type=password]');
  const usernameFields = () => fields([
    'input[autocomplete~=username]', 'input[autocomplete~=email]', 'input[type=email]',
    'input[name*=user i]', 'input[name*=email i]', 'input[name*=login i]', 'input[id*=user i]', 'input[id*=email i]',
  ].join(','));

  // Multi-step logins ask for the username on one screen and the password on the next.
  let rememberedUsername = '';

  const noticeUsername = () => {
    const value = usernameFields().map((f) => f.value.trim()).find(Boolean);
    if (value) rememberedUsername = value;
  };

  let announced = false;
  const look = () => {
    // Most pages have no sign-in form, and this one check costs them almost nothing.
    const candidate = document.querySelector('input[type=password],input[autocomplete~=username]');
    const present = !!candidate && (passwordFields().length > 0 || fields('input[autocomplete~=username]').length > 0);
    if (present !== announced) {
      announced = present;
      post({ t: 'loginForm', present });
    }
  };

  const capture = () => {
    noticeUsername();
    const password = passwordFields().map((f) => f.value).find(Boolean);
    if (password) post({ t: 'loginSubmit', username: rememberedUsername, password });
  };

  document.addEventListener('submit', capture, true);
  document.addEventListener('click', (e) => {
    noticeUsername();
    if (e.target.closest?.('button,input[type=submit],[role=button]')) capture();
  }, true);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.matches?.('input')) capture();
  }, true);

  let timer = 0;
  new MutationObserver(() => {
    if (timer) return;
    timer = setTimeout(() => { timer = 0; if (!document.hidden) look(); }, 800);
  }).observe(document.documentElement, { childList: true, subtree: true });
  look();

  const set = (field, value) => {
    field.focus();
    field.value = value;
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));
  };

  window.__c = {
    fill(host, username, password) {
      if (location.protocol !== 'https:' || location.host !== host) return;
      const user = usernameFields()[0];
      const pass = passwordFields()[0];
      if (user) set(user, username);
      if (pass) set(pass, password);
    },
  };
})();
