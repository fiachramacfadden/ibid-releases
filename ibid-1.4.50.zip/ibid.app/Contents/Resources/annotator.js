// Runs in ibid's isolated content world: the page cannot see this code, these
// marks, or the message handler. All ink is drawn on one sealed layer laid over the
// page, leaving the page's own elements untouched and its words unreadable to it.
//
// Scrolling is the thing a browser must never get in the way of, so the layer sits in
// document coordinates and moves with the page by itself. Ink is measured only when
// the layout changes. A page with no marks pays for nothing but one passive listener.
(() => {
  if (window.__m) return;

  const INKS = __INKS__;
  const post = (m) => { try { webkit.messageHandlers.marginalia.postMessage(m); } catch {} };

  const marks = new Map();

  // ---- The ink layer -------------------------------------------------------

  const host = document.createElement('ibid-ink');
  host.style.cssText = 'all:initial;position:absolute;left:0;top:0;width:0;height:0;overflow:clip;'
    + 'pointer-events:none;z-index:2147483647';
  const layer = host.attachShadow({ mode: 'closed' });
  // A fresh stroke blooms into place, from a little smaller and clear, in a seventh of a second: marking
  // happens all day, so it's barely there. The owner chose it on 2026-11-11 over fading in, a marker's
  // sweep (quick and quicker), wet ink settling, rising, wiping down, and a sweep that settles.
  const ARRIVAL = '@media(prefers-reduced-motion:no-preference){.arrives{animation:bloom .14s ease-out backwards}}'
    + '@keyframes bloom{from{opacity:0;transform:scale(.92)}}';
  layer.innerHTML = '<style>svg{position:absolute;overflow:visible}'
    + 'b{position:absolute;opacity:.8}'
    + 'u{position:absolute;background:rgba(120,120,128,.24)}'
    + 'i{position:absolute;background:Highlight;opacity:.5}' + ARRIVAL + '</style><div></div><div></div><div></div>';
  const [strokes, focusLayer, selectLayer] = layer.querySelectorAll('div');

  const ARRIVE_MS = 1500;
  // The class and delay for a stroke still arriving: its lines follow one another, and a redraw
  // midway carries on from where it was rather than starting again.
  const arriving = (born, index) => {
    if (!born) return { cls: '', delay: '' };
    const age = performance.now() - born;
    if (age > ARRIVE_MS) return { cls: '', delay: '' };
    return { cls: ' class="arrives"', delay: `animation-delay:${Math.round(index * 30 - age)}ms;` };
  };

  const eachText = (range, visit) => {
    const root = range.commonAncestorContainer;
    if (root.nodeType === Node.TEXT_NODE) {
      visit(root, range.startOffset, range.endOffset);
      return;
    }
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if (!range.intersectsNode(n)) continue;
      visit(n, n === range.startContainer ? range.startOffset : 0,
        n === range.endContainer ? range.endOffset : n.length);
    }
  };

  // One box per line, measured from the words alone: a range's own rects
  // would include whole paragraphs it happens to span.
  const lines = (range) => {
    const boxes = [];
    eachText(range, (node, start, end) => {
      if (!node.data.slice(start, end).trim()) return;
      const part = document.createRange();
      part.setStart(node, start);
      part.setEnd(node, end);
      for (const r of part.getClientRects()) if (r.width && r.height) boxes.push(r);
    });
    // Text runs in reading order, so a box can only belong to the line before it.
    const merged = [];
    for (const r of boxes) {
      const line = merged[merged.length - 1];
      if (line && Math.min(line.bottom, r.bottom) - Math.max(line.top, r.top) > r.height / 2) {
        line.left = Math.min(line.left, r.left);
        line.right = Math.max(line.right, r.right);
        line.top = Math.min(line.top, r.top);
        line.bottom = Math.max(line.bottom, r.bottom);
      } else {
        merged.push({ left: r.left, right: r.right, top: r.top, bottom: r.bottom });
      }
    }
    return merged;
  };

  // Text pinned to the screen stays put while the page moves, so its ink can't ride along.
  const isPinned = (element) => {
    for (let el = element; el; el = el.parentElement) {
      const { position } = getComputedStyle(el);
      if (position === 'fixed' || position === 'sticky') return true;
    }
    return false;
  };

  const homeOf = (range) => {
    const root = range.commonAncestorContainer;
    return root.nodeType === Node.ELEMENT_NODE ? root : root.parentElement;
  };

  const isDarkPage = () => {
    for (const element of [document.body, document.documentElement]) {
      if (!element) continue;
      const rgb = getComputedStyle(element).backgroundColor.match(/[\d.]+/g)?.map(Number);
      if (rgb && rgb[3] !== 0) return rgb[0] * 0.3 + rgb[1] * 0.59 + rgb[2] * 0.11 < 110;
    }
    return false;
  };

  // Seeded by the mark, so a stroke keeps its shape every time it's redrawn.
  const seeded = (text) => {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
    return () => {
      h = (h + 0x6D2B79F5) | 0;
      let t = Math.imul(h ^ (h >>> 15), 1 | h);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };

  // One stroke of a marker: it leans at both ends and its long edges are never quite
  // straight. Drawn as a loop of points with the corners smoothed through.
  const stroke = (width, height, spillX, spillY, rand) => {
    const jitter = (amount) => (rand() - 0.5) * height * amount;
    const steps = Math.max(2, Math.round(width / (height * 1.1)));
    const lean = height * (0.1 + rand() * 0.06);
    const left = -spillX * (0.7 + rand() * 0.6);
    const right = width + spillX * (0.7 + rand() * 0.6);
    const top = -spillY;
    const bottom = height + spillY;
    const loop = [];
    for (let i = 0; i <= steps; i++) loop.push([left + (right - left) * (i / steps) + lean, top + jitter(0.04)]);
    for (let i = 1; i < 4; i++) {
      const y = top + (bottom - top) * (i / 4);
      loop.push([right + lean * (1 - i / 2) + jitter(0.03), y]);
    }
    for (let i = steps; i >= 0; i--) loop.push([left + (right - left) * (i / steps) - lean, bottom + jitter(0.04)]);
    for (let i = 3; i > 0; i--) {
      const y = top + (bottom - top) * (i / 4);
      loop.push([left + lean * (1 - i / 2) + jitter(0.03), y]);
    }
    const middle = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    const point = ([x, y]) => `${x.toFixed(1)} ${y.toFixed(1)}`;
    const curves = loop.map((corner, i) => `Q${point(corner)} ${point(middle(corner, loop[(i + 1) % loop.length]))}`);
    return `M${point(middle(loop[loop.length - 1], loop[0]))}${curves.join('')}Z`;
  };

  // The browser's own CSS highlights would be simpler, but any script on the page can
  // read which words they cover.
  const measure = document.createElement('canvas').getContext('2d');
  const crisp = (length) => Math.round(length * devicePixelRatio) / devicePixelRatio;

  // Not the style's own font: that comes back empty as soon as a page sets anything unusual on it.
  const fontOf = (style) => `${style.fontStyle} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;

  // An underline's place below the line's box, in proportion to the type it runs under.
  const ruleFor = (range) => {
    const node = range.startContainer;
    const element = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    const style = element ? getComputedStyle(element) : null;
    if (!style) return { drop: 0, below: 1, thickness: 1, clearance: 2 };
    measure.font = fontOf(style);
    const size = parseFloat(style.fontSize);
    return {
      drop: measure.measureText('g').fontBoundingBoxDescent,
      below: crisp(Math.max(0.5, size * 0.06)),
      thickness: crisp(Math.max(1, size * 0.095)),
      clearance: size * 0.13,
    };
  };

  const glyph = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
  const crossings = new Map();
  const GLYPH_SCALE = 4;

  // The stretches a letter's ink keeps the underline out of, measured from the letter's start.
  // Letters are drawn off screen to find out, since only the tails of some reach that far.
  const crossing = (font, size, char, { below, thickness }) => {
    const key = `${font}|${char}|${below}|${thickness}`;
    if (crossings.has(key)) return crossings.get(key);
    const margin = Math.ceil(size);
    const baseline = Math.ceil(size * 1.5);
    glyph.canvas.width = margin * 3 * GLYPH_SCALE;
    glyph.canvas.height = Math.ceil(size * 2.2) * GLYPH_SCALE;
    glyph.scale(GLYPH_SCALE, GLYPH_SCALE);
    glyph.font = font;
    glyph.fillText(char, margin, baseline);
    const { data, width } = glyph.getImageData(0, 0, glyph.canvas.width, glyph.canvas.height);
    const inked = (x, y) => data[(y * width + x) * 4 + 3] > 48;
    const row = (at) => Math.floor((baseline + at) * GLYPH_SCALE);
    const bottom = row(below + thickness + 0.75);
    // Round letters dip a hair under the line they sit on, which isn't a tail.
    const top = row(size * 0.04);
    const inkAt = (x) => {
      for (let y = top; y < bottom; y++) if (inked(x, y)) return true;
      return false;
    };
    const spans = [];
    let start = -1;
    for (let x = 0; x <= width; x++) {
      const here = x < width && inkAt(x);
      if (here && start < 0) start = x;
      if (!here && start >= 0) {
        spans.push([start / GLYPH_SCALE - margin, x / GLYPH_SCALE - margin]);
        start = -1;
      }
    }
    crossings.set(key, spans);
    return spans;
  };

  const asShown = (char, transform) => {
    if (transform === 'uppercase') return char.toUpperCase();
    return transform === 'lowercase' ? char.toLowerCase() : char;
  };

  // Everywhere the words in a range would be crossed by their underline.
  const tails = (range, rule) => {
    const found = [];
    const letter = document.createRange();
    eachText(range, (node, start, end) => {
      const style = getComputedStyle(node.parentElement);
      const font = fontOf(style);
      const size = parseFloat(style.fontSize);
      let i = start;
      while (i < end) {
        const char = String.fromCodePoint(node.data.codePointAt(i));
        const spans = crossing(font, size, asShown(char, style.textTransform), rule);
        if (spans.length) {
          letter.setStart(node, i);
          letter.setEnd(node, i + char.length);
          const box = letter.getBoundingClientRect();
          for (const [from, to] of spans) {
            found.push({ middle: (box.top + box.bottom) / 2, left: box.left + from, right: box.left + to });
          }
        }
        i += char.length;
      }
    });
    return found;
  };

  // A line's underline, broken wherever a tail comes through.
  const ruleSegments = (line, crossed, clearance) => {
    const shortest = 3.5;
    const gaps = crossed
      .filter(({ middle }) => middle > line.top && middle < line.bottom)
      .sort((a, b) => a.left - b.left);
    const segments = [];
    let from = line.left;
    for (const { left, right } of gaps) {
      if (left - clearance - from >= shortest) segments.push([from, left - clearance]);
      from = Math.max(from, right + clearance);
    }
    if (line.right - from >= shortest) segments.push([from, line.right]);
    return segments.length ? segments : [[line.left, line.right]];
  };

  // Each line of ink: where its middle lies on the page, what it sits in, and its strokes.
  let places = [];
  let pinned = false;
  let drawn = '';
  let inkBox = { width: 0, height: 0 };
  let focusBox = { width: 0, height: 0 };
  let focused = null;
  let focusTimer = 0;
  let selectBox = { width: 0, height: 0 };
  let selectShown = false;

  const reach = (box, right, bottom) => {
    box.width = Math.max(box.width, right);
    box.height = Math.max(box.height, bottom);
  };

  // Blending needs a layer with real area, and sized to the ink it can't lengthen the page.
  // Only a page with something to show ever gets the layer at all.
  const fit = () => {
    const root = document.documentElement;
    if (!drawn && !focused && !selectShown) {
      host.remove();
      return;
    }
    host.style.width = `${Math.min(Math.max(inkBox.width, focusBox.width, selectBox.width), root.scrollWidth)}px`;
    host.style.height = `${Math.min(Math.max(inkBox.height, focusBox.height, selectBox.height), root.scrollHeight)}px`;
    if (!host.isConnected) root.append(host);
  };

  // The layer sits above everything, so ink under a sticky header or a popup has to hide.
  // Only what's on screen is asked about, which is why this can run mid-scroll.
  const cover = () => {
    for (const { x, y, home, ink } of places) {
      const left = x - scrollX;
      const top = y - scrollY;
      if (top < -64 || top > innerHeight + 64) continue;
      const visible = left >= 0 && top >= 0 && left < innerWidth && top < innerHeight;
      const over = visible ? document.elementFromPoint(left, top) : null;
      const shown = over && !home?.contains(over) && !over.contains(home) ? 'hidden' : '';
      if (ink[0].style.visibility !== shown) for (const stroke of ink) stroke.style.visibility = shown;
    }
  };

  const drawInk = () => {
    const box = { width: 0, height: 0 };
    const found = [];
    // Every rule is drawn after every wash: a highlight laid over an underlined passage would
    // otherwise paint the underline out (the owner underlined, then highlighted, and lost the line).
    let washes = '';
    let rules = '';
    pinned = false;
    for (const m of marks.values()) {
      if (!m.range) continue;
      const washed = m.style === 'highlight' || m.style === 'both';
      const ruled = m.style === 'underline' || m.style === 'both';
      if (!washed && !ruled) continue;
      const rule = ruled ? ruleFor(m.range) : null;
      const crossed = ruled ? tails(m.range, rule) : [];
      const home = homeOf(m.range);
      pinned ||= isPinned(home);
      lines(m.range).forEach((line, index) => {
        const width = line.right - line.left;
        const height = line.bottom - line.top;
        const x = line.left + scrollX;
        const y = line.top + scrollY;
        if (washed) {
          // The box holds the whole stroke, spill and lean included, so it can be revealed or moved as one.
          const pad = height * 0.4;
          const arrive = arriving(m.bornWash, index);
          washes += `<svg${arrive.cls} style="${arrive.delay}left:${x - pad}px;top:${y - pad}px;width:${width + pad * 2}px;height:${height + pad * 2}px"`
            + ` viewBox="${-pad} ${-pad} ${width + pad * 2} ${height + pad * 2}" fill="${INKS[m.ink].wash}">`
            + `<path d="${stroke(width, height, height * 0.14, height * 0.03, seeded(`${m.id}${index}`))}"/></svg>`;
        }
        const segments = ruled ? ruleSegments(line, crossed, rule.clearance) : [];
        const arrive = segments.length ? arriving(m.bornRule, index) : null;
        for (const [from, to] of segments) {
          rules += `<b${arrive.cls} style="${arrive.delay}left:${from + scrollX}px;top:${crisp(line.bottom - rule.drop + rule.below + scrollY)}px;`
            + `width:${to - from}px;height:${rule.thickness}px;background:${INKS[m.ink].line}"></b>`;
        }
        found.push({ x: x + width / 2, y: y + height / 2, home, wash: washed ? 1 : 0, rules: segments.length });
        reach(box, x + width + height, y + height * 2);
      });
    }
    const html = washes + rules;
    const blend = isDarkPage() ? 'normal' : 'multiply';
    const key = html && blend + html;
    if (key !== drawn) {
      drawn = key;
      strokes.innerHTML = html;
      inkBox = box;
      host.style.mixBlendMode = blend;
      host.style.opacity = blend === 'normal' ? 0.4 : 1;
    }
    const drawnStrokes = [...strokes.children];
    let nextWash = 0;
    let nextRule = found.reduce((n, place) => n + place.wash, 0);
    places = found.map((place) => ({
      ...place,
      ink: [...drawnStrokes.slice(nextWash, nextWash += place.wash), ...drawnStrokes.slice(nextRule, nextRule += place.rules)],
    }));
    fit();
  };

  const drawFocus = () => {
    const box = { width: 0, height: 0 };
    let html = '';
    if (focused) {
      for (const line of lines(focused)) {
        const width = line.right - line.left;
        const height = line.bottom - line.top;
        const x = line.left + scrollX;
        const y = line.top + scrollY;
        html += `<u style="left:${x}px;top:${y}px;width:${width}px;height:${height}px"></u>`;
        reach(box, x + width + height, y + height * 2);
      }
    }
    focusLayer.innerHTML = html;
    focusBox = box;
    fit();
  };

  // The browser paints a selection out to the page's edge wherever it crosses from one block to
  // the next. So its own is hidden and the selection is drawn behind the words alone, as marks are.
  const selectStyle = document.createElement('style');
  selectStyle.textContent = 'html[ibid-selecting] ::selection{background:transparent!important;color:inherit!important}';
  // Like lines, but a selection can run across columns, so words on one line only join up when
  // they're near each other, and text a page keeps out of sight for screen readers is left out.
  const selectedLines = (range) => {
    const merged = [];
    eachText(range, (node, start, end) => {
      if (!node.data.slice(start, end).trim()) return;
      const parent = node.parentElement;
      if (!parent?.checkVisibility({ visibilityProperty: true })) return;
      const own = parent.getBoundingClientRect();
      if (own.width <= 2 || own.height <= 2) return;
      const part = document.createRange();
      part.setStart(node, start);
      part.setEnd(node, end);
      for (const r of part.getClientRects()) {
        if (!r.width || !r.height) continue;
        const line = merged.find((l) => Math.min(l.bottom, r.bottom) - Math.max(l.top, r.top) > r.height / 2
          && r.left - l.right < r.height && l.left - r.right < r.height);
        if (line) {
          line.left = Math.min(line.left, r.left);
          line.right = Math.max(line.right, r.right);
          line.top = Math.min(line.top, r.top);
          line.bottom = Math.max(line.bottom, r.bottom);
        } else {
          merged.push({ left: r.left, right: r.right, top: r.top, bottom: r.bottom });
        }
      }
    });
    return merged;
  };

  const drawSelection = () => {
    const sel = getSelection();
    const range = sel && sel.rangeCount && !sel.isCollapsed && !isEditable(sel.anchorNode) ? sel.getRangeAt(0) : null;
    const box = { width: 0, height: 0 };
    let html = '';
    if (range) {
      for (const line of selectedLines(range)) {
        const width = line.right - line.left;
        const height = line.bottom - line.top;
        const x = line.left + scrollX;
        const y = line.top + scrollY;
        html += `<i style="left:${x}px;top:${y}px;width:${width}px;height:${height}px"></i>`;
        reach(box, x + width + height, y + height * 2);
      }
    }
    selectShown = !!html;
    if (selectShown) {
      if (!selectStyle.isConnected) (document.head ?? document.documentElement).append(selectStyle);
      document.documentElement.setAttribute('ibid-selecting', '');
    } else {
      document.documentElement.removeAttribute('ibid-selecting');
    }
    selectLayer.innerHTML = html;
    selectBox = box;
    fit();
  };
  let selectFrame = 0;
  const redrawSelection = () => {
    cancelAnimationFrame(selectFrame);
    selectFrame = requestAnimationFrame(drawSelection);
  };
  document.addEventListener('selectionchange', redrawSelection);

  const setFocus = (range, ms) => {
    clearTimeout(focusTimer);
    focused = range ?? null;
    drawFocus();
    if (focused && ms) focusTimer = setTimeout(() => setFocus(null, 0), ms);
  };

  // ---- Text index ----------------------------------------------------------
  // The page's text, with whitespace collapsed so anchors survive reflowed
  // markup. Offsets into this string are the only coordinates that get stored.

  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'TEXTAREA', 'SELECT', 'OPTION']);
  const isSpace = (ch) => /\s/.test(ch);
  let index = null;

  const buildIndex = () => {
    const nodes = [];
    const map = new Map();
    const parts = [];
    let length = 0;
    let space = true;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.parentNode && SKIP.has(n.parentNode.nodeName)
        ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
    });
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      let norm = n.data.replace(/\s+/g, ' ');
      const startsAfterSpace = space;
      if (space && norm[0] === ' ') norm = norm.slice(1);
      if (!norm) continue;
      map.set(n, nodes.length);
      nodes.push({ node: n, start: length, end: length + norm.length, space: startsAfterSpace });
      parts.push(norm);
      length += norm.length;
      space = norm[norm.length - 1] === ' ';
    }
    return { text: parts.join(''), nodes, map };
  };

  const getIndex = () => (index ??= buildIndex());

  const toNorm = (entry, raw) => {
    const data = entry.node.data;
    let count = 0;
    let space = entry.space;
    for (let i = 0; i < raw && i < data.length; i++) {
      if (isSpace(data[i])) { if (!space) { count++; space = true; } }
      else { count++; space = false; }
    }
    return entry.start + count;
  };

  const toRaw = (entry, norm) => {
    const data = entry.node.data;
    const target = norm - entry.start;
    let count = 0;
    let space = entry.space;
    for (let i = 0; i < data.length; i++) {
      const ws = isSpace(data[i]);
      if (count === target && !(ws && space)) return i;
      if (ws) { if (!space) { count++; space = true; } }
      else { count++; space = false; }
    }
    return data.length;
  };

  const entryAt = (idx, offset) => {
    let lo = 0;
    let hi = idx.nodes.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const e = idx.nodes[mid];
      if (offset < e.start) hi = mid - 1;
      else if (offset >= e.end) lo = mid + 1;
      else return e;
    }
    return null;
  };

  const pointToNorm = (idx, node, offset) => {
    if (idx.map.has(node)) return toNorm(idx.nodes[idx.map.get(node)], offset);
    const probe = new Range();
    probe.setStart(node, offset);
    probe.collapse(true);
    let lo = 0;
    let hi = idx.nodes.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (probe.comparePoint(idx.nodes[mid].node, 0) < 0) lo = mid + 1;
      else hi = mid;
    }
    return lo < idx.nodes.length ? idx.nodes[lo].start : idx.text.length;
  };

  const rangeFor = (idx, start, end) => {
    const a = entryAt(idx, start);
    const b = entryAt(idx, end - 1);
    if (!a || !b) return null;
    const range = new Range();
    range.setStart(a.node, toRaw(a, start));
    range.setEnd(b.node, toRaw(b, end - 1) + 1);
    return range;
  };

  // ---- Anchoring -----------------------------------------------------------

  const CONTEXT = 48;

  const describe = (range) => {
    const idx = getIndex();
    let start = pointToNorm(idx, range.startContainer, range.startOffset);
    let end = pointToNorm(idx, range.endContainer, range.endOffset);
    while (start < end && idx.text[start] === ' ') start++;
    while (end > start && idx.text[end - 1] === ' ') end--;
    if (end <= start) return null;
    return {
      exact: idx.text.slice(start, end),
      prefix: idx.text.slice(Math.max(0, start - CONTEXT), start),
      suffix: idx.text.slice(end, end + CONTEXT),
      start,
    };
  };

  const sharedTail = (a, b) => {
    let n = 0;
    while (n < a.length && n < b.length && a[a.length - 1 - n] === b[b.length - 1 - n]) n++;
    return n;
  };
  const sharedHead = (a, b) => {
    let n = 0;
    while (n < a.length && n < b.length && a[n] === b[n]) n++;
    return n;
  };

  // Sites can carry a second, hidden copy of their words, for phones or for search engines.
  // Ink on that copy is never seen, and nothing says the mark is missing.
  const shown = (idx, at) => entryAt(idx, at)?.node.parentElement?.checkVisibility({ visibilityProperty: true }) ?? true;

  const locateExact = (idx, a, text = idx.text) => {
    let best = null;
    let found = 0;
    for (let at = text.indexOf(a.exact); at >= 0 && found < 500; at = text.indexOf(a.exact, at + 1)) {
      found++;
      const before = text.slice(Math.max(0, at - a.prefix.length), at);
      const after = text.slice(at + a.exact.length, at + a.exact.length + a.suffix.length);
      const context = sharedTail(a.prefix, before) + sharedHead(a.suffix, after);
      const visible = shown(idx, at);
      // Words you can see come first. Hidden ones only stand in when there are no others.
      const score = (visible ? 0 : -10000) + context * 4 - Math.min(Math.abs(at - a.start) / 256, 8);
      if (!best || score > best.score) best = { at, end: at + a.exact.length, score, context };
    }
    if (!best) return null;
    // A short phrase with no surrounding context left is more likely a
    // coincidence than the original passage. Leave it unplaced rather than
    // painting the wrong words.
    const hadContext = a.prefix.length + a.suffix.length >= 8;
    if (a.exact.length < 32 && hadContext && best.context < 4) return null;
    return best;
  };

  // The passage was edited: find its opening and closing words, a plausible
  // distance apart, and accept whatever now lies between them.
  const locateByEnds = (idx, a) => {
    if (a.exact.length < 32) return null;
    const { text } = idx;
    const head = a.exact.slice(0, 16);
    const tail = a.exact.slice(-16);
    let best = null;
    let found = 0;
    for (let at = text.indexOf(head); at >= 0 && found < 500; at = text.indexOf(head, at + 1)) {
      found++;
      const min = at + Math.floor(a.exact.length * 0.5);
      const stop = text.indexOf(tail, min);
      if (stop < 0 || stop - at > a.exact.length * 1.5) continue;
      const distance = Math.abs(at - a.start);
      if (!best || distance < best.distance) best = { at, end: stop + tail.length, distance };
    }
    return best;
  };

  // Sites swap curly quotes for straight ones, and change a capital or a dash, without the
  // words having changed. One character always folds to one, so positions still line up.
  const fold = (s) => s.replace(/[A-Z]/g, (c) => c.toLowerCase())
    .replace(/[‘’ʼ′]/g, "'").replace(/[“”″]/g, '"').replace(/[‐‑‒–—−]/g, '-').replace(/\u00a0/g, ' ');

  const locateFolded = (idx, a) => {
    idx.folded ??= fold(idx.text);
    return locateExact(idx, { ...a, exact: fold(a.exact), prefix: fold(a.prefix), suffix: fold(a.suffix) }, idx.folded);
  };

  const wordsOf = (s) => s.toLowerCase().match(/[\p{L}\p{N}']+/gu) ?? [];

  // How much two passages share, from 0 to 1, whatever order their words are in.
  const overlap = (a, b) => {
    const left = new Map();
    for (const word of wordsOf(a)) left.set(word, (left.get(word) ?? 0) + 1);
    let shared = 0;
    const right = wordsOf(b);
    for (const word of right) {
      const count = left.get(word);
      if (count) { shared++; left.set(word, count - 1); }
    }
    return (2 * shared) / Math.max(1, wordsOf(a).length + right.length);
  };

  // The passage was reworded in places. Fragments of it lead to where it might now be, and that
  // spot only counts if nearly all its words are still there. A mark left unplaced is
  // honest, and a mark painted on the wrong words is not.
  const SIMILAR = 0.8;
  const locateSimilar = (idx, a) => {
    const exact = fold(a.exact);
    if (exact.length < 48) return null;
    idx.folded ??= fold(idx.text);
    const text = idx.folded;
    let best = null;
    for (const share of [0, 0.25, 0.5, 0.75]) {
      const offset = Math.floor(exact.length * share);
      const seed = exact.slice(offset, offset + 14);
      if (seed.length < 14) continue;
      let found = 0;
      for (let at = text.indexOf(seed); at >= 0 && found < 40; at = text.indexOf(seed, at + 1)) {
        found++;
        let start = Math.max(0, at - offset);
        let end = Math.min(text.length, start + exact.length);
        while (start > 0 && !isSpace(text[start - 1])) start--;
        while (end < text.length && !isSpace(text[end]) && end - start < exact.length * 1.2) end++;
        const score = overlap(exact, text.slice(start, end));
        if (score >= SIMILAR && (!best || score > best.score)) best = { at: start, end, score };
      }
    }
    return best;
  };

  const place = (m) => {
    const idx = getIndex();
    const hit = locateExact(idx, m.anchor) ?? locateFolded(idx, m.anchor) ?? locateByEnds(idx, m.anchor) ?? locateSimilar(idx, m.anchor);
    m.range = hit ? rangeFor(idx, hit.at, hit.end) : null;
  };

  const collapse = (s) => s.replace(/\s+/g, ' ').trim();

  const isIntact = (m) => m.range
    && m.range.startContainer.isConnected
    && m.range.endContainer.isConnected
    && collapse(m.range.toString()) === m.anchor.exact;

  // Pages often render after load, so nothing counts as missing until the page
  // has had a moment. Otherwise marks would flash up as lost on every visit.
  const GRACE = 4000;
  let loadedAt = 0;
  let reportedOrphans = null;
  const reportOrphans = () => {
    if (performance.now() - loadedAt < GRACE) return;
    const ids = [...marks.values()].filter((m) => !m.range).map((m) => m.id).sort();
    const key = ids.join();
    if (key !== reportedOrphans) {
      reportedOrphans = key;
      post({ t: 'orphans', ids });
    }
  };

  const settle = () => {
    let moved = false;
    for (const m of marks.values()) {
      if (isIntact(m)) continue;
      const had = m.range;
      place(m);
      moved = moved || had !== m.range;
    }
    reportOrphans();
    if (moved) invalidate();
    return moved;
  };

  // ---- Reporting positions to the margin -----------------------------------

  const firstRect = (range) => {
    for (const r of range.getClientRects()) if (r.width > 0 && r.height > 0) return r;
    return null;
  };

  /// The right edge of the text column a mark sits in.
  const columnRight = (range) => {
    let el = range.startContainer;
    if (el.nodeType !== 1) el = el.parentElement;
    while (el && el !== document.body && getComputedStyle(el).display.startsWith('inline')) el = el.parentElement;
    return el ? el.getBoundingClientRect().right : innerWidth;
  };

  let lastSpots = '';
  let lastScroll = 0;

  const reportNotes = () => {
    const items = [];
    for (const m of marks.values()) {
      if (!m.note || !m.range) continue;
      const r = firstRect(m.range);
      if (r) items.push([m.id, Math.round((r.top + scrollY) * 2) / 2, Math.round(columnRight(m.range))]);
    }
    const key = JSON.stringify(items);
    if (key !== lastSpots) {
      lastSpots = key;
      lastScroll = scrollY;
      post({ t: 'frame', items, y: scrollY });
    }
  };

  // Moving the notes along with a scroll needs one number, not a fresh look at the page.
  const reportScroll = () => {
    if (lastSpots.length > 2 && scrollY !== lastScroll) {
      lastScroll = scrollY;
      post({ t: 'scroll', y: scrollY });
    }
  };

  // ---- One frame -----------------------------------------------------------

  let framePending = false;
  let stale = false;
  let nextMeasure = 0;
  let measureTimer = 0;

  const remeasure = () => {
    const began = performance.now();
    stale = false;
    drawInk();
    if (focused) drawFocus();
    if (selectShown) drawSelection();
    reportNotes();
    // However busy the page, measuring it never takes more than a twentieth of its time.
    const now = performance.now();
    nextMeasure = now + (now - began) * 19;
  };

  const frame = () => {
    framePending = false;
    const now = performance.now();
    if (stale && now >= nextMeasure) {
      remeasure();
    } else if (stale && !measureTimer) {
      measureTimer = setTimeout(() => { measureTimer = 0; schedule(); }, nextMeasure - now);
    }
    cover();
    reportScroll();
    if (selectionLive) sendSelection(false);
  };

  const schedule = () => {
    if (framePending || !(marks.size || selectionLive || focused)) return;
    framePending = true;
    requestAnimationFrame(frame);
  };

  const invalidate = () => {
    stale = true;
    schedule();
  };

  // ---- Selection -----------------------------------------------------------

  let pointerDown = false;
  let selectionLive = false;
  let liveRange = null;
  let keyTimer = 0;

  const isEditable = (node) => {
    const el = node?.nodeType === 1 ? node : node?.parentElement;
    return !!el && (el.isContentEditable || !!el.closest('input,textarea,select'));
  };

  const boxOf = (range) => {
    let box = null;
    for (const r of range.getClientRects()) {
      if (!r.width || !r.height) continue;
      box ??= { top: r.top, bottom: r.bottom, left: r.left, right: r.right };
      box.bottom = r.bottom;
      box.left = Math.min(box.left, r.left);
      box.right = Math.max(box.right, r.right);
    }
    return box;
  };

  const sendSelection = (settled) => {
    const box = liveRange && boxOf(liveRange);
    post({ t: 'selection', box: box ?? null, covers: box ? covered() : [], settled, vw: innerWidth, vh: innerHeight });
  };

  // The visible marks that touch the selection, however slightly.
  const covered = () => [...marks.values()].filter((m) => m.range && m.style !== 'bare'
    && m.range.compareBoundaryPoints(Range.END_TO_START, liveRange) < 0
    && m.range.compareBoundaryPoints(Range.START_TO_END, liveRange) > 0).map((m) => m.id);

  const readSelection = (settled) => {
    const sel = getSelection();
    const usable = sel && sel.rangeCount && !sel.isCollapsed
      && !isEditable(sel.anchorNode) && sel.toString().trim();
    if (!usable) {
      if (selectionLive) {
        selectionLive = false;
        liveRange = null;
        post({ t: 'selection', box: null, settled: true });
      }
      return;
    }
    liveRange = sel.getRangeAt(0).cloneRange();
    selectionLive = true;
    sendSelection(settled);
  };

  document.addEventListener('pointerdown', () => { pointerDown = true; }, true);
  // A drag that turns into drag-and-drop never sends pointerup.
  document.addEventListener('dragend', () => { pointerDown = false; }, true);
  window.addEventListener('pointerup', () => {
    pointerDown = false;
    setTimeout(() => readSelection(true), 0);
  }, true);
  document.addEventListener('selectionchange', () => {
    if (pointerDown) return;
    clearTimeout(keyTimer);
    keyTimer = setTimeout(() => readSelection(false), 220);
  });

  // ---- Clicking an existing mark -------------------------------------------

  const hitTest = (x, y) => {
    let hit = null;
    for (const m of marks.values()) {
      if (!m.range) continue;
      for (const r of m.range.getClientRects()) {
        if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) {
          if (!hit || m.anchor.exact.length < hit.anchor.exact.length) hit = m;
          break;
        }
      }
    }
    return hit;
  };

  document.addEventListener('click', (e) => {
    if (!getSelection().isCollapsed) return;
    const interactive = e.target.closest?.('a,button,input,textarea,select,label,summary,[role=button]');
    const hit = interactive ? null : hitTest(e.clientX, e.clientY);
    if (hit) post({ t: 'markClick', id: hit.id, box: boxOf(hit.range), vw: innerWidth, vh: innerHeight });
    else post({ t: 'dismiss' });
  }, true);

  // ---- Keeping up with the page --------------------------------------------

  let lastY = 0;
  let lastResizedAt = 0;
  let lastDirection = 0;
  let lastToldAt = 0;
  let pulledUp = 0;
  let pullStartedAt = 0;
  let lastStepAt = 0;
  // The top row comes back for a brisk pull up, or a long one, never for the small slow scrolls of
  // re-reading a line. A finger settling at the end of a swipe moves the page a few pixels up, and
  // the row returning on that reflowed the words; 40 and then 80 pixels of travel still felt too eager.
  const FLICK = 160, FLICK_MS = 400, LONG_PULL = 400, PULL_GAP_MS = 150;

  // Tells the app which way the reader is heading: down at once, up after a real pull, and rarely otherwise.
  const noteDirection = (scroller) => {
    if (!scroller || scroller.clientHeight < innerHeight / 2) return;
    // Rubber-banding past either end isn't the reader changing direction.
    const room = scroller.scrollHeight - scroller.clientHeight;
    const y = Math.min(Math.max(scroller.scrollTop, 0), room);
    // The top row going gives the page more height, which pulls it back from the bottom by itself.
    const now = performance.now();
    const resized = now - lastResizedAt < 100;
    const step = y - lastY;
    lastY = y;
    let direction = 0;
    if (y <= 8) {
      direction = -1;
      pulledUp = 0;
    } else if (resized || (room < 120 && step > 0)) {
      // A page with hardly any room to scroll would run out of it the moment the row went.
    } else if (step > 0) {
      direction = 1;
      pulledUp = 0;
    } else if (step < 0) {
      // A pause ends a pull, so nudges minutes apart never add up to one.
      if (pulledUp === 0 || now - lastStepAt > PULL_GAP_MS) { pulledUp = 0; pullStartedAt = now; }
      pulledUp -= step;
      const brisk = pulledUp >= FLICK && now - pullStartedAt <= FLICK_MS;
      if (brisk || pulledUp >= LONG_PULL) direction = -1;
    }
    if (step) lastStepAt = now;
    if (direction && (direction !== lastDirection || now - lastToldAt > 200)) {
      lastDirection = direction;
      lastToldAt = now;
      post({ t: 'scrolled', direction });
    }
  };

  // How far the page has scrolled, while its top is near enough to matter: a bookmarked page's
  // turned-over corner belongs to the top of the page and goes up with it.
  let toldTop = 0;
  const reportTop = () => {
    const top = Math.min(240, Math.max(0, Math.round(scrollY)));
    if (top === toldTop) return;
    toldTop = top;
    post({ t: 'top', y: top });
  };

  addEventListener('scroll', (event) => {
    const page = event.target === document;
    if (page) reportTop();
    // Web apps often scroll a panel rather than the page. Small boxes don't count.
    noteDirection(page ? document.scrollingElement : event.target);
    // The ink rides along with the page by itself, but not with a panel inside it.
    if (page ? pinned : [...marks.values()].some((m) => m.range && event.target.contains?.(m.range.startContainer))) stale = true;
    schedule();
  }, { capture: true, passive: true });

  addEventListener('resize', () => {
    lastResizedAt = performance.now();
    invalidate();
  }, { passive: true });
  // Captured, so every image and frame that finishes counts: each can push the text along.
  addEventListener('load', invalidate, { capture: true, passive: true });
  document.fonts?.ready.then(invalidate);
  const sizeWatch = new ResizeObserver(invalidate);

  // Pages keep rendering after load, so marks are looked for again as the DOM changes.
  // A page that never stops changing is searched less and less, down to every four seconds.
  let settleTimer = 0;
  let settleGap = 1000;
  const changes = new MutationObserver((records) => {
    const own = records.filter((r) => r.target !== host);
    if (!own.length) return;
    invalidate();
    // A class or a style can move the text about, but only new words need finding again.
    if (own.every((r) => r.type === 'attributes')) return;
    index = null;
    if (settleTimer) return;
    settleTimer = setTimeout(() => {
      settleTimer = 0;
      settleGap = settle() ? 1000 : Math.min(settleGap * 2, 4000);
    }, settleGap);
  });

  // Only a page with marks on it needs watching.
  const watch = () => {
    sizeWatch.disconnect();
    changes.disconnect();
    if (!marks.size) return;
    sizeWatch.observe(document.documentElement);
    if (document.body) sizeWatch.observe(document.body);
    changes.observe(document.documentElement, {
      childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class', 'style', 'hidden', 'open'],
    });
  };

  // ---- The API Swift calls -------------------------------------------------

  const inked = (a) => ({ id: a.id, ink: a.ink, style: a.style, anchor: a.anchor, note: !!a.note.length, range: null });

  // The reader asks to hear how far through you are.
  let followsReading = false;
  let readingTimer = 0;
  addEventListener('scroll', () => {
    if (!followsReading || readingTimer) return;
    readingTimer = setTimeout(() => {
      readingTimer = 0;
      const most = document.documentElement.scrollHeight - innerHeight;
      if (most > 0) post({ t: 'reading', p: Math.min(1, scrollY / most) });
    }, 800);
  }, { passive: true });

  window.__m = {
    // `href` guards against a navigation that has started but not yet replaced
    // this document: its marks belong to the next page, not this one.
    load(json, href) {
      if (href && href !== location.href) return false;
      index = null;
      marks.clear();
      for (const a of JSON.parse(json)) marks.set(a.id, inked(a));
      lastSpots = '';
      reportedOrphans = null;
      loadedAt = performance.now();
      for (const m of marks.values()) place(m);
      watch();
      remeasure();
      setTimeout(reportOrphans, GRACE + 50);
      return true;
    },
    // Describes the current selection, returning a JSON anchor and its box.
    capture() {
      if (!liveRange) return null;
      // Nothing keeps the index fresh on a page without marks.
      if (!marks.size) index = null;
      const anchor = describe(liveRange);
      return anchor ? JSON.stringify({ anchor, box: boxOf(liveRange), vw: innerWidth, vh: innerHeight }) : null;
    },
    add(json) {
      const m = inked(JSON.parse(json));
      if (liveRange) m.range = liveRange.cloneRange();
      else place(m);
      m.bornWash = m.bornRule = performance.now();
      marks.set(m.id, m);
      watch();
      remeasure();
      this.clearSelection();
    },
    restyle(id, ink, style) {
      const m = marks.get(id);
      if (!m) return;
      // Only what's new arrives: a line added to a highlight draws itself under the wash that's already there.
      const had = m.style;
      const now = performance.now();
      if ((style === 'highlight' || style === 'both') && had !== 'highlight' && had !== 'both') m.bornWash = now;
      if ((style === 'underline' || style === 'both') && had !== 'underline' && had !== 'both') m.bornRule = now;
      m.ink = ink;
      m.style = style;
      remeasure();
    },
    setNote(id, hasNote) {
      const m = marks.get(id);
      if (!m) return;
      m.note = hasNote;
      remeasure();
    },
    remove(id) {
      marks.delete(id);
      watch();
      remeasure();
      reportOrphans();
    },
    focus(id) {
      const m = marks.get(id);
      if (!m?.range) return false;
      const el = m.range.startContainer.nodeType === 1 ? m.range.startContainer : m.range.startContainer.parentElement;
      el?.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' });
      setFocus(m.range, 1600);
      return true;
    },
    hover(id) {
      setFocus(id ? marks.get(id)?.range : null, 0);
    },
    clearSelection() {
      selectionLive = false;
      liveRange = null;
      getSelection()?.removeAllRanges();
    },
    // The words a mark currently covers, or null if it has no place on the page.
    markedText(id) {
      const range = marks.get(id)?.range;
      return range ? collapse(range.toString()) : null;
    },
    // The element around a mark, and how many lines of ink are showing.
    markedElement(id) {
      const root = marks.get(id)?.range?.commonAncestorContainer;
      return root?.nodeType === Node.TEXT_NODE ? root.parentElement : root ?? null;
    },
    inkLines() {
      return layer.querySelectorAll('svg').length;
    },
    selectionText() {
      return liveRange ? liveRange.toString() : '';
    },
    followReading() {
      followsReading = true;
    },
    // Words from the top of what's on screen, to find the same place in another view of the page.
    spot() {
      if (scrollY < 60) return null;
      for (const el of document.querySelectorAll('p,li,blockquote,h1,h2,h3,h4')) {
        const box = el.getBoundingClientRect();
        if (box.top < 0 || box.height === 0) continue;
        const words = collapse(el.textContent);
        if (words.length >= 40) return words.slice(0, 80);
      }
      return null;
    },
    goToSpot(text) {
      index = null;
      const idx = getIndex();
      const words = collapse(text).slice(0, 70);
      const at = idx.text.indexOf(words);
      if (at < 0) return false;
      const range = rangeFor(idx, at, at + words.length);
      const box = range ? firstRect(range) : null;
      if (!box) return false;
      // By the words themselves: on an old page their element can be the whole article.
      scrollTo(0, box.top + scrollY - 48);
      return true;
    },
  };

  const icon = () => {
    let best = null;
    let bestSize = -1;
    for (const link of document.querySelectorAll('link[rel~="icon"],link[rel="apple-touch-icon"]')) {
      const size = parseInt(link.sizes?.value) || (link.rel.includes('apple') ? 180 : 16);
      if (size > bestSize) { best = link.href; bestSize = size; }
    }
    return best ?? new URL('/favicon.ico', location.href).href;
  };

  // Where a link really goes, whatever its words say. Shown in the corner before it's clicked.
  let hoveredHref = '';
  const hoverLink = (e) => {
    const href = e.target.closest?.('a[href]')?.href;
    const next = typeof href === 'string' ? href : '';
    if (next !== hoveredHref) {
      hoveredHref = next;
      post({ t: 'link', href: next });
    }
  };
  document.addEventListener('mouseover', hoverLink, { capture: true, passive: true });

  // Typing the app must not throw away by putting this tab to sleep. Said once per page.
  document.addEventListener('input', () => post({ t: 'edited' }), { capture: true, passive: true, once: true });

  const ready = () => post({ t: 'ready', href: location.href, icon: icon() });
  ready();
  // A page restored from the back/forward cache keeps this script but needs its marks again.
  addEventListener('pageshow', (e) => { if (e.persisted) ready(); });
})();
